package Main;

import Interfaces.Bienvenida;
import Interfaces.Menu;

/**
 *
 * @author nicolepinto
 */
public class Main {

    public static void main(String[] args) {
               Bienvenida ventana = new Bienvenida();
        ventana.setVisible(true);
    }
    
}
